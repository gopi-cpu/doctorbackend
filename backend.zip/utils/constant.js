const success ={
    SUCCESS:"user cerated suceess",
    LOGIN:"user login"
}

const error={
    ERROR:"user already there",
    LOGIN:"wrong password"
}

module.exports =  {success,error}